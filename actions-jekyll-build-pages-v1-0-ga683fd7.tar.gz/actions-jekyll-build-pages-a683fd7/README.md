# Jekyll-Build-Pages

A simple GitHub Action for producing Jekyll build artifacts compatible with GitHub Pages.

# Scope

This is used along with [`actions/deploy-pages`](https://github.com/actions/deploy-pages) as part of the official support for building Pages with Actions (currently in public beta for public repositories).

# Usage

See [action.yml](action.yml)

# License

The scripts and documentation in this project are released under the [MIT License](LICENSE).
