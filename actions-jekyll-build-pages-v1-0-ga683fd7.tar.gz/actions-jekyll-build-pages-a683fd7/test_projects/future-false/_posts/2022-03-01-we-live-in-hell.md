---
title: We Live In Hell
---

And it's not even the cool hell that \[redacted\] are afraid of. 😭
