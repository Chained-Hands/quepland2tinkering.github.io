---
title: The Future is Looking Bright!
---

Everything's coming up Milhouse.
